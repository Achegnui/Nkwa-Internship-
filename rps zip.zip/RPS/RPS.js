const rock = document.getElementById("rock");
const paper = document.getElementById("paper");
const scissors = document.getElementById("scissors");
const display_comp = document.getElementById("display_comp");
const object = document.getElementById("object");
const display = document.getElementById("display");
const objects = [
  {
    rock: `<img src="rock.jpg" style = "height: 100%; width: 100%; border-radius: 0.5em;"/>`,
  },
  {
    paper: `<img src="paper.jpg" style = "height: 100%; width: 100%; border-radius: 0.5em;"/>`,
  },
  {
    scissors: `<img src="scissors.jpg" style = "height: 100%; width: 100%; border-radius: 0.5em;"/>`,
  },
];

countDown();
rock.addEventListener("click", function () {
  display.innerHTML = objects[0].rock;
  // const user_Selection = object[0].rock;
  const filtered = objects.filter((item) => item == "rock");
  console.log("Answer", filtered);
  random();
  // const comp_Selection = random();

  // compare(user_Selection, comp_Selection);

  // const test = random();
  // console.log("Test", test);
});

paper.addEventListener("click", function () {
  display.innerHTML = objects[1].paper;
  random();
});

scissors.addEventListener("click", function () {
  display.innerHTML = objects[2].scissors;
  random();
});

const timer = document.getElementById("timer");
var count;
function countDown() {
  let countdown = 4;
  const interval = setInterval(() => {
    countdown--;
    if (countdown === 0) {
      timer.textContent = "GO";

      clearInterval(interval);
    } else {
      timer.textContent = countdown;
    }
  }, 1000);
}

function random() {
  var rand = Math.floor(Math.random() * objects.length);

  const randomObject = objects[rand];
  const value = Object.values(randomObject)[0];

  display_comp.innerHTML = value;

  return rand;
}

function compare(user_Selection, comp_Selection) {
  random();
  if (user_Selection == comp_Selection) {
    timer.textContent = "Tie";
  } else if (
    (user_Selection == object[0].rock && comp_Selection == object[1].paper) ||
    (user_Selection == object[1].paper && comp_Selection == object[0].rock) ||
    (user_Selection == object[2].scissors && comp_Selection == object[1].paper)
  ) {
    timer.textContent = "You win";
  } else {
    timer.textContent = "You lose";
  }
}
